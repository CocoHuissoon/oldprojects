package nl.hva.miw.oop2.c12.hertentamen.boodschappen;

import java.util.ArrayList;
import java.util.List;

public class Boodschappenlijst {
	
	/** 
	 * De lijst van artikelen
	 */
	private List<Artikel> lijst = new ArrayList<>();
	
	/**
	 * Voeg een artikel aan de boodschappenlijst toe.
	 * 
	 * @param a
	 */
	public void voegArtikelToe( Artikel a ) {
		// Implementeer deze methode
	}

	/**
	 * Retourneert de artikelen in deze boodschappenlijst.
	 * j
	 * @return
	 */
	public List<Artikel> getLijstArtikelen() {
		return lijst;
	}

	/**
	 * Print artikelen in deze boodschappenlijst. 
	 */
	public void printBoodschappenLijst() {
		System.out.println("Boodschappenlijst: [ ");
		for ( Artikel a : lijst ) {
			System.out.println("  " + a);
		}
	}
	
	
	/**
	 * Sorteert de artikelen in deze boodschappenlijst in de "Natural Order" van de artikelen.
	 */
	public void sorteer() {
		// Implmenteer deze methode
	}

	/**
	 * Sorteert de artikelen in deze boodschappenlijst op basis van de gegeven Comparator.
	 * LET OP: verander de method declaratie ook indien nodig!
	 */
	public void sorteer( XXX ) {
		// Implementeer deze methode
	}
}
