/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop2.toets;

import dit.niet.veranderen.Getal;
import java.util.List;

/**
 *
 * @author huub
 */
public class Stap3 {
  
  public Stap3() {
    super();
  }
  
  public static void main(String[] args) {
    Stap3 opg = new Stap3();
    opg.writeOutput(opg.leesBinaireData("getallen.dat"));
  }
  
  private List<Getal> leesBinaireData(String filenaam) {
    // Deze methode moet je afmaken voor Stap 3
    return null;
  }
  
  private void writeOutput(List<Getal> getallen) {
    // Deze methode moet je afmaken voor Stap 3
  }
  
}
