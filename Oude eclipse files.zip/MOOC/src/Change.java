
public class Change {
	public static void main(String[] args) {
		
	
	public double makeChange(double moneyGiven,double itemCost){
		 double change = moneyGiven-itemCost;
		 return change;
	}
	
}
}