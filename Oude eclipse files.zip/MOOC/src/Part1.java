public class Part1 {
	public static void main (String[]args) {
		
	

	double dice = Math.random();
	dice = dice*10;
	int dice2= (int)dice;
	if (dice2>6) {
		
	}
	System.out.println(dice2);
		
	}
}

	/*System.out.print("Hello world! \n(And all the people of the world)\n");
	System.out.println("      *\n     ***\n    *****\n   *******\n  *********\n      *");
	
	
	String chick= "Chickens:\n";
	int chickbuck= 9000;
	String pig = "\nBacon (kg):\n";
	double pigbuck= 0.1;
	String trac = "\nA tractor:\nZetor\n";
	String nut = "\nInt a nutshell:\n";
	System.out.println(chick + chickbuck + pig + pigbuck + trac + nut  + chickbuck +"\n"+ pigbuck + "\nZetor");
	
	int secondInYear= 365 * 24 * 60 *60;
	System.out.println("There are "+ secondInYear+ " in a year");
	int x=111 ;
	int y=277 ;
	int sum= x*y;
	System.out.println(y +" * " + x +" = " +sum);
	
	
	int age= 99;
	System.out.println("How old are you? " + age);
	if (age>0 && age<120) {
		System.out.println("Ok");
	}else {
		System.out.println("Impossibru!");
	}
	 String username= "cat";
	 String password = "sploo";
	 System.out.println("Type ur username: " + username);
	 System.out.println("Type ur password: " + password);
	 if (username.equals("alex")&& password.equals("mightyducks")||username.equals("cat")&& password.equals("sploo"))
			 {
			 System.out.println("Ur logged in!");}
		 else {
			 System.out.println("Getoutahea!");
			 
		 }
	 
		 
	 }
	}
}
*/