
public interface Istartable {
	public void start();
	public void stop();
	

}
