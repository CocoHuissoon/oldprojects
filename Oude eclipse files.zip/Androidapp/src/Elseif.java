
public class Elseif {

	public static void main(String[] args) {

		int money = 200;
		int age = 18;
		public void pr0n() {
		if (money > +100 && age >= 18) {
			System.out.println("Here's your porn you scumbag");
		}
		if (money < 100) {
			System.out.println("getoutahe ya bum!");
		}
		if (age < 18) {
			System.out.println("kid");
		}
		}

	}

}
