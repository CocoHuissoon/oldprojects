
public class Plant {
	public void grow() {
		System.out.println("Im growing!");
	}
}
