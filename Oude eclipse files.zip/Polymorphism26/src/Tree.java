
public class Tree extends Plant {

	@Override
	public void grow() {
		System.out.println("Im dying!");
	}
	public void shedLeaves() {
		System.out.println("My babies!");
	}

}
