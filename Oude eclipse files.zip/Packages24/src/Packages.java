import ocean.Fish;
import ocean.plants.Seaweed;

public class Packages {

	public static void main(String[] args) {
		Fish fish = new Fish();
		Seaweed weed = new Seaweed();
		
	}

}
